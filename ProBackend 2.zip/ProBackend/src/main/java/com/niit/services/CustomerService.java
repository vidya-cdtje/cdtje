package com.niit.services;

import com.niit.model.Customer;

public interface CustomerService {
void registerCustomer(Customer customer);
}