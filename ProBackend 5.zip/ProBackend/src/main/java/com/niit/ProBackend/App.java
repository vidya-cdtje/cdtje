package com.niit.ProBackend;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.niit.Configuration.DBConfiguration;
import com.niit.dao.CustomerDao;
import com.niit.dao.ProductDao;
import com.niit.model.Authorities;
import com.niit.model.Category;
import com.niit.model.Customer;
import com.niit.model.Product;
import com.niit.model.User;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx= new AnnotationConfigApplicationContext(DBConfiguration.class);
    	CustomerDao customerDao=ctx.getBean(CustomerDao.class);
    	
    	User user=new User();
    	user.setEmail("a@gmail.com");
    	user.setEnabled(true);
    	user.setPassword("123");
    	
    	Authorities authorities=new Authorities();
    	authorities.setRole("ROLE_USER");
    	authorities.setUser(user);
    	
    	Customer customer=new Customer();
    	customer.setFirstname("admin");
    	customer.setLastname("a");
    	customer.setPhonenumber("123");
    	customer.setUser(user);
    	
    	customerDao.registerCustomer(customer);
    	
    	/*
    	 ProductDao productDao=ctx.getBean(ProductDao.class);
    	Category c=new Category();
    	c.setCategoryname("Mobile");
    	Product p=new Product();
    	p.setProductname("Mobile");
    	p.setProductdescription("samsung");
    	p.setPrice(100000);
    	productDao.saveOrUpdateProduct(p);
        System.out.println( "Hello World!" );
    */
    }
}
