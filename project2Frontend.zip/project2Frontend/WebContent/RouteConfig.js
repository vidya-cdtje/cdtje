/**
 * route!
 */
var myModule=angular.module("MyModule", ['ngRoute']);
myModule.config(function($routeProvider)
{
	alert('this is route conofig');
	$routeProvider.when("/",{templateUrl:"/index.html"})
				  .when("/login",{templateUrl:"f_user/Login.html"})
				  .when("/register",{templateUrl:"f_user/Register.html"})
				  .when("/home",{templateUrl:"f_headerpages/Home.html"})
				  .when("/aboutus",{templateUrl:"f_headerpages/AboutUs.html"})
				  .when("/contactus",{templateUrl:"f_headerpages/ContactUs.html"})
				  
	});