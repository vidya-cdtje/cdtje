package com.niit.ProBackend;

import junit.framework.TestCase;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
/*static SupplierDAO supplierDAO;
	
	@BeforeClass
	public static void setup()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		supplierDAO=(SupplierDAO)context.getBean("supplierDAO");
	}*/
	
	
	/*@Test
	public void addSupplierTestCase()
	{
		Supplier supplier=new Supplier();
		supplier.setSupplierName("BlueInfoSystem");
		supplier.setSupplierAddr("Hyderabad");
		
		assertTrue("Problem in Adding Supplier",supplierDAO.addSupplier(supplier));
	}
    public AppTest( String testName )
    {
        super( testName );
    }*/

    /**
     * @return the suite of tests being tested
     */
    /*public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }*/

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
        assertTrue( true );
    }
}
